<?php
session_start();
if (!isset($_SESSION['user_id'])) {
    header('Location: login.php');
    exit();
}
$host = 'localhost';
$db   = 'agro_lab_db';
$user = 'root';
$pass = '';
$charset = 'utf8mb4';
$dsn = "mysql:host=$host;dbname=$db;charset=$charset";
$options = [
    PDO::ATTR_ERRMODE            => PDO::ERRMODE_EXCEPTION,
    PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
    PDO::ATTR_EMULATE_PREPARES   => false,
];
try {
    $pdo = new PDO($dsn, $user, $pass, $options);
} catch (PDOException $e) {
    die('Database connection failed: ' . $e->getMessage());
}
$cvFiles = $pdo->query('SELECT name, email, cv_file, created_at FROM stage_requests WHERE cv_file IS NOT NULL ORDER BY created_at DESC')->fetchAll();
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Files - Uploaded CVs</title>
    <link rel="stylesheet" href="css/bootstrap.min.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <style>
        body {
            background: #f4f7fa;
            font-family: 'Inter', 'Roboto', Arial, sans-serif;
        }
        /* Sidebar style from formation_requests.php */
.sidebar { position: fixed; top: 0; left: 0; bottom: 0; width: 250px; background: #232946; color: #fff; z-index: 1000; padding-top: 32px; display: flex; flex-direction: column; }
.sidebar .logo { font-size: 1.5rem; font-weight: 700; letter-spacing: 1px; margin-bottom: 2rem; display: flex; align-items: center; padding-left: 32px; }
.sidebar .logo i { font-size: 2rem; margin-right: 10px; color: #7c3aed; }
.sidebar .section-title { font-size: 0.75rem; color: #a1a7bb; text-transform: uppercase; margin: 1.5rem 0 0.5rem 32px; letter-spacing: 1px; }
.sidebar .nav-link { color: #e0e7ff; padding: 10px 32px; border-radius: 8px; display: flex; align-items: center; font-weight: 500; margin-bottom: 4px; transition: background 0.2s, color 0.2s; text-decoration: none; }
.sidebar .nav-link.active, .sidebar .nav-link:hover { background: #353a5a; color: #7c3aed; }
.sidebar .nav-link i { margin-right: 12px; font-size: 1.2rem; }
.sidebar .disabled { opacity: 0.5; pointer-events: none; }
.main-content { margin-left: 250px; min-height: 100vh; background: #f4f7fa; padding: 0; }
.dashboard-container { padding: 40px 40px 0 40px; }
.card { border-radius: 16px !important; box-shadow: 0 4px 18px rgba(33,150,243,0.07); border: none; }
.card-title { font-size: 1.1rem; font-weight: 600; }
@media (max-width: 991px) {
    .main-content { margin-left: 0; }
    .sidebar { position: relative; width: 100%; min-height: 0; }
    .dashboard-container { padding: 20px 5px 0 5px; }
}
    </style>
</head>
<body>
<div class="sidebar">
    <div class="logo"><i class="fa-solid fa-flask-vial"></i> DashboardKit</div>
    <div class="section-title">NAVIGATION</div>
    <a href="dashboard.php" class="nav-link"><i class="fa-solid fa-house"></i>Dashboard</a>
    <a href="files.php" class="nav-link active"><i class="fa-solid fa-file-lines"></i>Files</a>
    <a href="formation_requests.php" class="nav-link"><i class="fa-solid fa-chalkboard-user"></i>Formation Requests</a>
    <a href="messages.php" class="nav-link"><i class="fa-solid fa-envelope"></i>Messages</a>
</div>
<div class="main-content">
    <div class="dashboard-container">
        <div class="card p-4 mb-4">
            <div class="card-title mb-3">Uploaded CVs</div>
            <div class="table-responsive">
                <table class="table table-bordered align-middle">
                    <thead class="table-light">
                        <tr>
                            <th>Name</th>
                            <th>Email</th>
                            <th>CV</th>
                            <th>Uploaded At</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach ($cvFiles as $cv): ?>
                            <tr>
                                <td><?= htmlspecialchars($cv['name']) ?></td>
                                <td><?= htmlspecialchars($cv['email']) ?></td>
                                <td>
                                    <a href="cv_uploads/<?= urlencode($cv['cv_file']) ?>" target="_blank">Download CV</a>
                                </td>
                                <td><?= htmlspecialchars($cv['created_at']) ?></td>
                            </tr>
                        <?php endforeach; ?>
                        <?php if (empty($cvFiles)): ?>
                            <tr><td colspan="4" class="text-center">No CVs uploaded yet.</td></tr>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</div>
<script src="js/bootstrap.min.js"></script>
</body>
</html> 