<?php
require_once 'config.php';

try {
    // Make user_id nullable
    $pdo->exec("ALTER TABLE stage_requests MODIFY user_id INT");
    
    // Get updated table structure
    $columns = $pdo->query("DESCRIBE stage_requests");
    $columns = $columns->fetchAll(PDO::FETCH_ASSOC);
    
    echo "Table structure updated:\n";
    foreach ($columns as $column) {
        echo "Column: " . $column['Field'] . " - Type: " . $column['Type'] . "\n";
    }
    
} catch (PDOException $e) {
    error_log("Error altering table: " . $e->getMessage());
    echo "Error: " . $e->getMessage();
}
?>
