<?php
session_start();
require_once 'google_config.php';

// Générer un état aléatoire pour la sécurité
$_SESSION['google_state'] = bin2hex(random_bytes(16));

// Construire l'URL d'autorisation Google
$params = [
    'client_id' => GOOGLE_CLIENT_ID,
    'redirect_uri' => GOOGLE_REDIRECT_URI,
    'response_type' => 'code',
    'scope' => GOOGLE_SCOPES,
    'state' => $_SESSION['google_state'],
    'access_type' => 'offline',
    'prompt' => 'consent'
];

$auth_url = GOOGLE_AUTH_URL . '?' . http_build_query($params);

// Rediriger vers Google
header('Location: ' . $auth_url);
exit();
?> 