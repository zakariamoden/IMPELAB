
SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";

--

CREATE TABLE `contact_messages` (
  `id` int(11) NOT NULL,
  `user_id` int(11) DEFAULT NULL,
  `name` varchar(100) DEFAULT NULL,
  `email` varchar(150) DEFAULT NULL,
  `message` text DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Structure de la table `dashboard_stats`
--

CREATE TABLE `dashboard_stats` (
  `id` int(11) NOT NULL,
  `stat` varchar(50) NOT NULL,
  `value` int(11) NOT NULL DEFAULT 0,
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Déchargement des données de la table `dashboard_stats`
--

INSERT INTO `dashboard_stats` (`id`, `stat`, `value`, `updated_at`) VALUES
(1, 'total_users', 0, '2025-07-14 13:28:21'),
(2, 'total_stages', 0, '2025-07-14 13:28:21'),
(3, 'total_formations', 1, '2025-07-14 13:28:21'),
(4, 'total_messages', 0, '2025-07-14 13:28:21');

-- --------------------------------------------------------

--
-- Structure de la table `formation_categories`
--

CREATE TABLE `formation_categories` (
  `id` int(11) NOT NULL,
  `name` varchar(100) NOT NULL,
  `description` text DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Déchargement des données de la table `formation_categories`
--

INSERT INTO `formation_categories` (`id`, `name`, `description`, `created_at`) VALUES
(1, 'Default', 'Default category', '2025-07-14 13:48:43');

-- --------------------------------------------------------

--
-- Structure de la table `formation_requests`
--

CREATE TABLE `formation_requests` (
  `id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `category_id` int(11) DEFAULT NULL,
  `title` varchar(255) NOT NULL,
  `description` text NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Déchargement des données de la table `formation_requests`
--

INSERT INTO `formation_requests` (`id`, `user_id`, `category_id`, `title`, `description`, `created_at`) VALUES
(43, 1, 1, 'Test Title', 'Test Description', '2025-07-14 15:09:56');

-- --------------------------------------------------------

--
-- Structure de la table `formation_requests_temp`
--

CREATE TABLE `formation_requests_temp` (
  `id` int(11) NOT NULL,
  `user_id` int(11) DEFAULT NULL,
  `category_id` int(11) DEFAULT NULL,
  `title` varchar(255) NOT NULL,
  `description` text NOT NULL,
  `email` varchar(255) NOT NULL,
  `status` varchar(50) DEFAULT 'pending',
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Déchargement des données de la table `formation_requests_temp`
--

INSERT INTO `formation_requests_temp` (`id`, `user_id`, `category_id`, `title`, `description`, `email`, `status`, `created_at`) VALUES
(1, 1, 1, 'Test Title', 'Test Description', '', 'pending', '2025-07-14 15:09:56'),
(2, 1, 1, 'Test Title', 'Test Description', '', 'pending', '2025-07-14 15:09:56'),
(3, 1, 1, 'Test Title', 'Test Description', '', 'pending', '2025-07-14 15:09:56'),
(4, 1, 1, 'Test Title', 'Test Description', '', 'pending', '2025-07-14 15:09:56'),
(5, 1, 1, 'Test Title', 'Test Description', '', 'pending', '2025-07-14 15:09:56');

-- --------------------------------------------------------

--
-- Structure de la table `formation_tags`
--

CREATE TABLE `formation_tags` (
  `id` int(11) NOT NULL,
  `name` varchar(50) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Structure de la table `formation_tags_mapping`
--

CREATE TABLE `formation_tags_mapping` (
  `formation_id` int(11) NOT NULL,
  `tag_id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Structure de la table `messages`
--

CREATE TABLE `messages` (
  `id` int(11) NOT NULL,
  `name` varchar(100) NOT NULL,
  `email` varchar(150) NOT NULL,
  `phone` varchar(20) DEFAULT NULL,
  `service` varchar(100) NOT NULL,
  `message` text NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Déchargement des données de la table `messages`
--

INSERT INTO `messages` (`id`, `name`, `email`, `phone`, `service`, `message`, `created_at`) VALUES
(37, 'zoooooooooooook', 'tgfefffzd@gmail.com', '0694286309', 'Analyses microbiologiques', 'kkkkkkkkk', '2025-07-10 13:01:12'),
(38, 'massssssssar', 'maaasaaaaaa@gmail.com', '12345', '', 'jjjjjjjjj', '2025-07-10 13:34:58'),
(39, 'massssssssar', 'maaasaaaaaa@gmail.com', '12345', '', 'hhhhhhhhhhhh', '2025-07-10 13:41:27'),
(40, 'massssssssar', 'maaasaaaaaa@gmail.com', '12345', '', 'hhhhhhhhhhhh', '2025-07-10 14:41:55'),
(41, 'n', 'maaasaaaaaa@gmail.com', '12345', '', 'kkkkk', '2025-07-11 11:16:24'),
(42, 'n', 'maaasaaaaaa@gmail.com', '12345', '', 'kkkkk', '2025-07-11 11:18:28'),
(43, 'zakaria modn', 'tgfefffzd@gmail.com', '0694286309', '', 'kkkkkk', '2025-07-11 11:18:37'),
(44, 'zakaria modn', 'tgfefffzd@gmail.com', '0694286309', '', 'kkkkkk', '2025-07-11 11:23:24'),
(46, 'zakaria modn', 'tgfefffzd@gmail.com', '0694286309', '', 'kkkkkk', '2025-07-11 11:31:17'),
(47, 'zakaria modn', 'tgfefffzd@gmail.com', '0694286309', '', 'hhhhhhhhhhhhhh', '2025-07-11 11:33:50'),
(48, 'zakaria modn', 'tgfefffzd@gmail.com', '0694286309', '', 'hhhhhhhhhhhhhhhhh', '2025-07-11 11:34:43'),
(49, 'zakaria modn', 'tgfefffzd@gmail.com', '0694286309', '', 'jjjjjjjjjjjjjh', '2025-07-11 11:35:27'),
(50, 'zakaria modn', 'tgfefffzd@gmail.com', '0694286309', '', 'jjjjjjjjjjjjjh', '2025-07-11 11:36:31'),
(51, 'zakaria modn', 'tgfefffzd@gmail.com', '0694286309', '', 'wwwwwwwwwwwwwww', '2025-07-11 11:36:40'),
(52, 'zoooooooooooook', 'tgfefffzd@gmail.com', '0694286309', 'Analyses microbiologiques', 'qqqqqqqqqqqqqqqqqqqq', '2025-07-14 08:49:30'),
(53, 'zoooooooooooook', 'tgfefffzd@gmail.com', '0694286309', 'Analyses microbiologiques', 'qwertyui', '2025-07-14 08:53:06'),
(55, 'mohamed', 'moamed@gmail.com', '1234567890', 'Analyses microbiologiques', 'wdfvy g', '2025-07-14 09:19:52'),
(56, 'zakaria modn', 'tgfefffzd@gmail.com', '0694286309', '', 'helllllllo', '2025-07-14 09:20:10'),
(57, 'zoook', 'mohamed@gmail.com', '1234567890', 'Analyses microbiologiques', '33333333333333', '2025-07-14 13:13:17'),
(58, 'zakaria modn', 'tgfefffzd@gmail.com', '0694286309', '', 'kkkkkkkk', '2025-07-14 13:13:33'),
(59, 'zakaria modn', 'tgfefffzd@gmail.com', '0694286309', '', 'nnnnnnn', '2025-07-14 13:13:48');

-- --------------------------------------------------------

--
-- Structure de la table `notifications`
--

CREATE TABLE `notifications` (
  `id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `title` varchar(255) NOT NULL,
  `message` text NOT NULL,
  `type` varchar(50) NOT NULL,
  `related_id` int(11) DEFAULT NULL,
  `related_type` varchar(50) DEFAULT NULL,
  `is_read` tinyint(1) DEFAULT 0,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Structure de la table `stage_requests`
--

CREATE TABLE `stage_requests` (
  `id` int(11) NOT NULL,
  `user_id` int(11) DEFAULT NULL,
  `company_name` varchar(255) DEFAULT NULL,
  `company_address` varchar(255) DEFAULT NULL,
  `company_email` varchar(255) DEFAULT NULL,
  `company_phone` varchar(255) DEFAULT NULL,
  `start_date` date DEFAULT NULL,
  `end_date` date DEFAULT NULL,
  `status` varchar(20) DEFAULT 'pending',
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `name` varchar(255) DEFAULT NULL,
  `email` varchar(255) DEFAULT NULL,
  `cv_file` varchar(255) DEFAULT NULL,
  `message` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Déchargement des données de la table `stage_requests`
--

INSERT INTO `stage_requests` (`id`, `user_id`, `company_name`, `company_address`, `company_email`, `company_phone`, `start_date`, `end_date`, `status`, `created_at`, `name`, `email`, `cv_file`, `message`) VALUES
(1, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'refused', '2025-07-14 12:45:50', 'zakaria modn', 'tgfefffzd@gmail.com', 'cv_6874fbfe86953.pdf', 'cccccccccc'),
(2, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'accepted', '2025-07-14 12:46:03', 'zakaria modn', 'tgfefffzd@gmail.com', 'cv_6874fc0be6f8e.pdf', 'ccccccccccc'),
(3, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'accepted', '2025-07-14 12:49:06', 'zakaria modn', 'tgfefffzd@gmail.com', 'cv_6874fcc2f11ed.pdf', 'cccccccccc');

-- --------------------------------------------------------

--
-- Structure de la table `users`
--

CREATE TABLE `users` (
  `id` int(11) NOT NULL,
  `email` varchar(255) NOT NULL,
  `password` varchar(255) NOT NULL,
  `full_name` varchar(255) NOT NULL,
  `role` varchar(20) DEFAULT 'user',
  `profile_picture` varchar(255) DEFAULT NULL,
  `phone_number` varchar(20) DEFAULT NULL,
  `bio` text DEFAULT NULL,
  `preferred_language` varchar(10) DEFAULT 'en',
  `last_active` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `google_id` varchar(255) DEFAULT NULL,
  `name` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Déchargement des données de la table `users`
--

INSERT INTO `users` (`id`, `email`, `password`, `full_name`, `role`, `profile_picture`, `phone_number`, `bio`, `preferred_language`, `last_active`, `created_at`, `google_id`, `name`) VALUES
(1, 'admin@agro-lab.com', '$2y$10$dPd.q.6x0MqX1S9BpzLuBungniSsAYvdbhuo0S9t.ttLBDGWyK07W', 'System Administrator', 'admin', NULL, NULL, NULL, 'en', '2025-07-11 11:35:03', '2025-07-11 11:35:03', NULL, NULL),
(2, 'tgfefffzd@gmail.com', '', '', 'user', NULL, NULL, NULL, 'en', '2025-07-14 09:18:27', '2025-07-14 09:18:27', '108918675636709167660', 'Fffzd Tgfe');

-- --------------------------------------------------------

--
-- Structure de la table `user_favorites`
--

CREATE TABLE `user_favorites` (
  `user_id` int(11) NOT NULL,
  `formation_id` int(11) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Index pour les tables déchargées
--

--
-- Index pour la table `contact_messages`
--
ALTER TABLE `contact_messages`
  ADD PRIMARY KEY (`id`);

--
-- Index pour la table `dashboard_stats`
--
ALTER TABLE `dashboard_stats`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `stat` (`stat`);

--
-- Index pour la table `formation_categories`
--
ALTER TABLE `formation_categories`
  ADD PRIMARY KEY (`id`);

--
-- Index pour la table `formation_requests`
--
ALTER TABLE `formation_requests`
  ADD PRIMARY KEY (`id`),
  ADD KEY `user_id` (`user_id`),
  ADD KEY `category_id` (`category_id`);

--
-- Index pour la table `formation_requests_temp`
--
ALTER TABLE `formation_requests_temp`
  ADD PRIMARY KEY (`id`),
  ADD KEY `category_id` (`category_id`);

--
-- Index pour la table `formation_tags`
--
ALTER TABLE `formation_tags`
  ADD PRIMARY KEY (`id`);

--
-- Index pour la table `formation_tags_mapping`
--
ALTER TABLE `formation_tags_mapping`
  ADD PRIMARY KEY (`formation_id`,`tag_id`),
  ADD KEY `tag_id` (`tag_id`);

--
-- Index pour la table `messages`
--
ALTER TABLE `messages`
  ADD PRIMARY KEY (`id`);

--
-- Index pour la table `notifications`
--
ALTER TABLE `notifications`
  ADD PRIMARY KEY (`id`),
  ADD KEY `idx_user_id` (`user_id`),
  ADD KEY `idx_is_read` (`is_read`),
  ADD KEY `idx_type` (`type`),
  ADD KEY `idx_created_at` (`created_at`);

--
-- Index pour la table `stage_requests`
--
ALTER TABLE `stage_requests`
  ADD PRIMARY KEY (`id`),
  ADD KEY `user_id` (`user_id`);

--
-- Index pour la table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `email` (`email`);

--
-- Index pour la table `user_favorites`
--
ALTER TABLE `user_favorites`
  ADD PRIMARY KEY (`user_id`,`formation_id`),
  ADD KEY `formation_id` (`formation_id`);

--
-- AUTO_INCREMENT pour les tables déchargées
--

--
-- AUTO_INCREMENT pour la table `contact_messages`
--
ALTER TABLE `contact_messages`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT pour la table `dashboard_stats`
--
ALTER TABLE `dashboard_stats`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT pour la table `formation_categories`
--
ALTER TABLE `formation_categories`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT pour la table `formation_requests`
--
ALTER TABLE `formation_requests`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=44;

--
-- AUTO_INCREMENT pour la table `formation_requests_temp`
--
ALTER TABLE `formation_requests_temp`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT pour la table `formation_tags`
--
ALTER TABLE `formation_tags`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT pour la table `messages`
--
ALTER TABLE `messages`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=60;

--
-- AUTO_INCREMENT pour la table `notifications`
--
ALTER TABLE `notifications`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT pour la table `stage_requests`
--
ALTER TABLE `stage_requests`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT pour la table `users`
--
ALTER TABLE `users`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- Contraintes pour les tables déchargées
--

--
-- Contraintes pour la table `formation_requests`
--
ALTER TABLE `formation_requests`
  ADD CONSTRAINT `formation_requests_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`),
  ADD CONSTRAINT `formation_requests_ibfk_2` FOREIGN KEY (`category_id`) REFERENCES `formation_categories` (`id`);

--
-- Contraintes pour la table `formation_requests_temp`
--
ALTER TABLE `formation_requests_temp`
  ADD CONSTRAINT `formation_requests_temp_ibfk_1` FOREIGN KEY (`category_id`) REFERENCES `formation_categories` (`id`);

--
-- Contraintes pour la table `formation_tags_mapping`
--
ALTER TABLE `formation_tags_mapping`
  ADD CONSTRAINT `formation_tags_mapping_ibfk_1` FOREIGN KEY (`formation_id`) REFERENCES `formation_requests` (`id`),
  ADD CONSTRAINT `formation_tags_mapping_ibfk_2` FOREIGN KEY (`tag_id`) REFERENCES `formation_tags` (`id`);

--
-- Contraintes pour la table `notifications`
--
ALTER TABLE `notifications`
  ADD CONSTRAINT `notifications_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`);

--
-- Contraintes pour la table `stage_requests`
--
ALTER TABLE `stage_requests`
  ADD CONSTRAINT `stage_requests_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`);

--
-- Contraintes pour la table `user_favorites`
--
ALTER TABLE `user_favorites`
  ADD CONSTRAINT `user_favorites_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`),
  ADD CONSTRAINT `user_favorites_ibfk_2` FOREIGN KEY (`formation_id`) REFERENCES `formation_requests` (`id`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
