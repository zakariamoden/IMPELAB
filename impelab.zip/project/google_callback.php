<?php
session_start();
require_once 'google_config.php';
require_once 'config.php';

// Vérifier si on a reçu un code d'autorisation
if (!isset($_GET['code'])) {
    $_SESSION['errors'] = ['Erreur: Code d\'autorisation manquant'];
    header('Location: login.php');
    exit();
}

// Vérifier l'état pour la sécurité
if (!isset($_GET['state']) || $_GET['state'] !== $_SESSION['google_state']) {
    $_SESSION['errors'] = ['Erreur: État invalide'];
    header('Location: login.php');
    exit();
}

// Échanger le code contre un token d'accès
$token_data = [
    'client_id' => GOOGLE_CLIENT_ID,
    'client_secret' => GOOGLE_CLIENT_SECRET,
    'code' => $_GET['code'],
    'grant_type' => 'authorization_code',
    'redirect_uri' => GOOGLE_REDIRECT_URI
];

$ch = curl_init();
curl_setopt($ch, CURLOPT_URL, GOOGLE_TOKEN_URL);
curl_setopt($ch, CURLOPT_POST, true);
curl_setopt($ch, CURLOPT_POSTFIELDS, http_build_query($token_data));
curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
curl_setopt($ch, CURLOPT_HTTPHEADER, ['Content-Type: application/x-www-form-urlencoded']);

$response = curl_exec($ch);
curl_close($ch);

$token_info = json_decode($response, true);

if (!isset($token_info['access_token'])) {
    $_SESSION['errors'] = ['Erreur: Impossible d\'obtenir le token d\'accès'];
    header('Location: login.php');
    exit();
}

// Obtenir les informations de l'utilisateur
$ch = curl_init();
curl_setopt($ch, CURLOPT_URL, GOOGLE_USERINFO_URL . '?access_token=' . $token_info['access_token']);
curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);

$user_response = curl_exec($ch);
curl_close($ch);

$user_info = json_decode($user_response, true);

if (!isset($user_info['id'])) {
    $_SESSION['errors'] = ['Erreur: Impossible d\'obtenir les informations utilisateur'];
    header('Location: login.php');
    exit();
}

// Start transaction
try {
    $pdo->beginTransaction();
    
    // Vérifier si l'utilisateur existe déjà
    $stmt = $pdo->prepare("SELECT * FROM users WHERE google_id = ? OR email = ?");
    $stmt->execute([$user_info['id'], $user_info['email']]);
    $user = $stmt->fetch();

    if ($user) {
        // Utilisateur existe, le connecter
        $_SESSION['user_id'] = $user['id'];
        $_SESSION['user_name'] = $user['name'];
        $_SESSION['user_email'] = $user['email'];
        $_SESSION['logged_in'] = true;
        
        // Mettre à jour google_id si nécessaire
        if (!$user['google_id']) {
            $stmt = $pdo->prepare("UPDATE users SET google_id = ? WHERE id = ?");
            $stmt->execute([$user_info['id'], $user['id']]);
            
            // Store picture in session
            $_SESSION['user_picture'] = $user_info['picture'];
        }
        
        // Commit transaction
        $pdo->commit();
        
        header('Location: index.html');
        exit();
    } else {
        // Nouvel utilisateur, l'inscrire
        $stmt = $pdo->prepare("INSERT INTO users (name, email, google_id) VALUES (?, ?, ?)");
        $stmt->execute([
            $user_info['name'],
            $user_info['email'],
            $user_info['id']
        ]);
        
        $user_id = $pdo->lastInsertId();
        
        // Connecter le nouvel utilisateur
        $_SESSION['user_id'] = $user_id;
        $_SESSION['user_name'] = $user_info['name'];
        $_SESSION['user_email'] = $user_info['email'];
        $_SESSION['logged_in'] = true;
        
        // Commit transaction
        $pdo->commit();
        
        // Store picture in session for now
        $_SESSION['user_picture'] = $user_info['picture'];
        
        header('Location: index.html');
        exit();
    }
} catch (PDOException $pdoError) {
    // Rollback transaction if anything fails
    $pdo->rollBack();
    $_SESSION['errors'] = ['Erreur de base de données: ' . $pdoError->getMessage()];
    header('Location: login.php');
    exit();
} catch (Exception $e) {
    // Rollback transaction if anything fails
    $pdo->rollBack();
    $_SESSION['errors'] = ['Erreur lors de la connexion avec Google: ' . $e->getMessage()];
    header('Location: login.php');
    exit();
}
?>