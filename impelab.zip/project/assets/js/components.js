function createStatCard(title, number, iconClass) {
    return `
        <div class="stat-card mb-4">
            <div class="d-flex align-items-center">
                <div class="icon-lab me-3">
                    <i class="${iconClass}"></i>
                </div>
                <div>
                    <h6 class="mb-1">${title}</h6>
                    <h3 class="number mb-0">${number}</h3>
                </div>
            </div>
        </div>
    `;
}

function createDashboardCard(title, content) {
    return `
        <div class="card dashboard-card mb-4">
            <div class="card-body">
                <h5 class="card-title mb-3">${title}</h5>
                ${content}
            </div>
        </div>
    `;
}

function createLoadingSpinner() {
    return `
        <div class="text-center py-5">
            <div class="spinner-border text-primary" role="status">
                <span class="visually-hidden">Loading...</span>
            </div>
        </div>
    `;
}

function createAlert(message, type = 'success') {
    const alertClasses = {
        success: 'alert-success bg-success bg-opacity-10 text-success',
        error: 'alert-danger bg-danger bg-opacity-10 text-danger',
        info: 'alert-info bg-info bg-opacity-10 text-info'
    };
    
    return `
        <div class="alert ${alertClasses[type]} alert-dismissible fade show" role="alert">
            ${message}
            <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
        </div>
    `;
}

// Add smooth scrolling for navigation
function smoothScroll() {
    document.querySelectorAll('a[href^="#"]').forEach(anchor => {
        anchor.addEventListener('click', function (e) {
            e.preventDefault();
            const target = document.querySelector(this.getAttribute('href'));
            if (target) {
                target.scrollIntoView({
                    behavior: 'smooth'
                });
            }
        });
    });
}
