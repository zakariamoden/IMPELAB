<?php
session_start();
require_once 'config.php';
$errors = [];
$success = false;
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $name = trim($_POST['name']);
    $email = trim($_POST['email']);
    $password = $_POST['password'];
    $confirm_password = $_POST['confirm_password'];
    if (empty($name)) {
        $errors[] = 'Name is required.';
    }
    if (empty($email)) {
        $errors[] = 'Email is required.';
    }
    if (empty($password)) {
        $errors[] = 'Password is required.';
    }
    if ($password !== $confirm_password) {
        $errors[] = 'Passwords do not match.';
    }
    if (empty($errors)) {
        try {
            $stmt = $pdo->prepare('SELECT id FROM users WHERE email = ?');
            $stmt->execute([$email]);
            if ($stmt->fetch()) {
                $errors[] = 'Email already exists.';
            } else {
                $hashed = password_hash($password, PASSWORD_DEFAULT);
                $stmt = $pdo->prepare('INSERT INTO users (name, email, password) VALUES (?, ?, ?)');
                $stmt->execute([$name, $email, $hashed]);
                $success = true;
                header('Location: login.php?registered=1');
                exit();
            }
        } catch (PDOException $e) {
            $errors[] = 'Database error: ' . $e->getMessage();
        }
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Register</title>
    <link rel="stylesheet" href="css/bootstrap.min.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <style>
        body {
            background: #f4f7fa;
            font-family: 'Inter', 'Roboto', Arial, sans-serif;
        }
        .sidebar {
            position: fixed;
            top: 0; left: 0; bottom: 0;
            width: 250px;
            background: #232946;
            color: #fff;
            z-index: 1000;
            padding-top: 32px;
            display: flex;
            flex-direction: column;
        }
        .sidebar .logo {
            font-size: 1.5rem;
            font-weight: 700;
            letter-spacing: 1px;
            margin-bottom: 2rem;
            display: flex;
            align-items: center;
            padding-left: 32px;
        }
        .sidebar .logo i {
            font-size: 2rem;
            margin-right: 10px;
            color: #7c3aed;
        }
        .sidebar .section-title {
            font-size: 0.75rem;
            color: #a1a7bb;
            text-transform: uppercase;
            margin: 1.5rem 0 0.5rem 32px;
            letter-spacing: 1px;
        }
        .sidebar .nav-link {
            color: #e0e7ff;
            padding: 10px 32px;
            border-radius: 8px;
            display: flex;
            align-items: center;
            font-weight: 500;
            margin-bottom: 4px;
            transition: background 0.2s, color 0.2s;
        }
        .sidebar .nav-link.active, .sidebar .nav-link:hover {
            background: #353a5a;
            color: #7c3aed;
        }
        .sidebar .nav-link i {
            margin-right: 12px;
            font-size: 1.2rem;
        }
        .sidebar .disabled {
            opacity: 0.5;
            pointer-events: none;
        }
        .main-content {
            margin-left: 250px;
            min-height: 100vh;
            background: #f4f7fa;
            padding: 0;
        }
        .dashboard-container {
            padding: 40px 40px 0 40px;
        }
        .card {
            border-radius: 16px !important;
            box-shadow: 0 4px 18px rgba(33,150,243,0.07);
            border: none;
        }
        .card-title {
            font-size: 1.1rem;
            font-weight: 600;
        }
        @media (max-width: 991px) {
            .main-content { margin-left: 0; }
            .sidebar { position: relative; width: 100%; min-height: 0; }
            .dashboard-container { padding: 20px 5px 0 5px; }
        }
    </style>
</head>
<body>
<div class="sidebar">
    <div class="logo"><i class="fa-solid fa-flask-vial"></i> DashboardKit</div>
    <div class="section-title">Navigation</div>
    <a href="dashboard.php" class="nav-link"><i class="fa-solid fa-house"></i>Dashboard</a>
    <a href="files.php" class="nav-link"><i class="fa-solid fa-file-lines"></i>Files</a>
    <a href="formation_requests.php" class="nav-link"><i class="fa-solid fa-chalkboard-user"></i>Formation Requests</a>
    <a href="messages.php" class="nav-link"><i class="fa-solid fa-envelope"></i>Messages</a>
</div>
<div class="main-content">
    <div class="dashboard-container">
        <div class="card p-4 mb-4" style="max-width:500px;margin:auto;">
            <div class="card-title mb-3">Register</div>
            <?php if (!empty($errors)): ?>
                <div class="alert alert-danger">
                    <?php foreach ($errors as $error): ?>
                        <div><?= htmlspecialchars($error) ?></div>
                    <?php endforeach; ?>
                </div>
            <?php endif; ?>
            <form method="post" autocomplete="off">
                <div class="mb-3">
                    <label for="name" class="form-label">Name</label>
                    <input type="text" class="form-control" id="name" name="name" required value="<?= isset($name) ? htmlspecialchars($name) : '' ?>">
                </div>
                <div class="mb-3">
                    <label for="email" class="form-label">Email</label>
                    <input type="email" class="form-control" id="email" name="email" required value="<?= isset($email) ? htmlspecialchars($email) : '' ?>">
                </div>
                <div class="mb-3">
                    <label for="password" class="form-label">Password</label>
                    <input type="password" class="form-control" id="password" name="password" required>
                </div>
                <div class="mb-3">
                    <label for="confirm_password" class="form-label">Confirm Password</label>
                    <input type="password" class="form-control" id="confirm_password" name="confirm_password" required>
                </div>
                <button type="submit" class="btn btn-primary w-100">Register</button>
            </form>
            <div class="mt-3 text-center">
                Already have an account? <a href="login.php">Login</a>
            </div>
        </div>
    </div>
</div>
<script src="js/bootstrap.min.js"></script>
</body>
</html> 