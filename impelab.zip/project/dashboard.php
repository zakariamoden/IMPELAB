<?php
session_start();
// Redirect to login if not authenticated
if (!isset($_SESSION['user_id'])) {
    header('Location: dashboard_login.php');
    exit();
}

// Use centralized database connection
require_once 'config.php';

// Initialize messages count
$messagesCount = 0;

// Get messages count
try {
    $stmt = $pdo->prepare("SELECT COUNT(*) as count FROM messages");
    $stmt->execute();
    $result = $stmt->fetch(PDO::FETCH_ASSOC);
    if ($result) {
        $messagesCount = $result['count'];
    }
} catch (PDOException $e) {
    error_log("Failed to get messages count: " . $e->getMessage());
    $messagesCount = 0;
}

// Fetch stats with prepared statements
try {
    $totalUsers = $pdo->query('SELECT COUNT(*) FROM users')->fetchColumn();
    $totalStages = $pdo->query('SELECT COUNT(*) FROM stage_requests')->fetchColumn();
    $totalFormations = $pdo->query('SELECT COUNT(*) FROM formation_requests')->fetchColumn();
    $totalMessages = $messagesCount;
} catch (PDOException $e) {
    error_log("Failed to fetch stats: " . $e->getMessage());
    $totalUsers = $totalStages = $totalFormations = $totalMessages = 0;
}

// Fetch data for analytics graphs
try {
    $stmt = $pdo->query("SELECT DATE(created_at) as date, COUNT(*) as count 
                        FROM messages 
                        WHERE created_at >= DATE_SUB(CURDATE(), INTERVAL 7 DAY) 
                        GROUP BY DATE(created_at)");
    $messagesPerDay = $stmt->fetchAll(PDO::FETCH_ASSOC);
    
    // Service distribution
    $stmt = $pdo->query("SELECT service, COUNT(*) as count 
                        FROM messages 
                        GROUP BY service");
    $serviceDistribution = $stmt->fetchAll(PDO::FETCH_ASSOC);
    
    // Stage requests status
    $stmt = $pdo->query("SELECT status, COUNT(*) as count 
                        FROM stage_requests 
                        GROUP BY status");
    $stageStatus = $stmt->fetchAll(PDO::FETCH_ASSOC);
    
    // User activity (last 30 days)
    $stmt = $pdo->query("SELECT DATE(last_active) as date, COUNT(*) as count 
                        FROM users 
                        WHERE last_active >= DATE_SUB(CURDATE(), INTERVAL 30 DAY) 
                        GROUP BY DATE(last_active)");
    $userActivity = $stmt->fetchAll(PDO::FETCH_ASSOC);
} catch (PDOException $e) {
    error_log("Failed to fetch analytics data: " . $e->getMessage());
    $messagesPerDay = [];
    $serviceDistribution = [];
    $stageStatus = [];
    $userActivity = [];
}

// Fetch recent stage requests
$recentStages = $pdo->query('SELECT * FROM stage_requests ORDER BY created_at DESC LIMIT 10')->fetchAll();
// Fetch recent formation requests
$recentFormations = $pdo->query('SELECT * FROM formation_requests ORDER BY created_at DESC LIMIT 5')->fetchAll();
// Fetch users
$users = $pdo->query('SELECT * FROM users ORDER BY created_at DESC LIMIT 10')->fetchAll();

// Fetch current user's name for header
$stmt = $pdo->prepare('SELECT name FROM users WHERE id = ?');
$stmt->execute([$_SESSION['user_id']]);
$currentUser = $stmt->fetch(PDO::FETCH_ASSOC);
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Dashboard</title>
    <link rel="stylesheet" href="css/bootstrap.min.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
    <style>
        :root {
            --primary-color: #7c3aed;
            --primary-light: #e0e7ff;
            --primary-dark: #353a5a;
            --bg-dark: #232946;
            --text-dark: #232946;
            --text-light: #e0e7ff;
            --border-color: #e5e7eb;
            --shadow-sm: 0 4px 18px rgba(33,150,243,0.07);
        }

        body {
            background: #f8fafc;
            font-family: 'Inter', 'Roboto', Arial, sans-serif;
            color: var(--text-dark);
            line-height: 1.6;
        }

        /* Sidebar style from formation_requests.php */
.sidebar { position: fixed; top: 0; left: 0; bottom: 0; width: 250px; background: #232946; color: #fff; z-index: 1000; padding-top: 32px; display: flex; flex-direction: column; }
.sidebar .logo { font-size: 1.5rem; font-weight: 700; letter-spacing: 1px; margin-bottom: 2rem; display: flex; align-items: center; padding-left: 32px; }
.sidebar .logo i { font-size: 2rem; margin-right: 10px; color: #7c3aed; }
.sidebar .section-title { font-size: 0.75rem; color: #a1a7bb; text-transform: uppercase; margin: 1.5rem 0 0.5rem 32px; letter-spacing: 1px; }
.sidebar .nav-link { color: #e0e7ff; padding: 10px 32px; border-radius: 8px; display: flex; align-items: center; font-weight: 500; margin-bottom: 4px; transition: background 0.2s, color 0.2s; }
.sidebar .nav-link.active, .sidebar .nav-link:hover { background: #353a5a; color: #7c3aed; }
.sidebar .nav-link i { margin-right: 12px; font-size: 1.2rem; }
.sidebar .disabled { opacity: 0.5; pointer-events: none; }
.main-content { margin-left: 250px; min-height: 100vh; background: #f4f7fa; padding: 0; }
.dashboard-container { padding: 40px 40px 0 40px; }
.card { border-radius: 16px !important; box-shadow: 0 4px 18px rgba(33,150,243,0.07); border: none; }
.card-title { font-size: 1.1rem; font-weight: 600; }
@media (max-width: 991px) {
    .main-content { margin-left: 0; }
    .sidebar { position: relative; width: 100%; min-height: 0; }
    .dashboard-container { padding: 20px 5px 0 5px; }
}

        .header { background: #fff; padding: 24px 32px 16px 32px; display: flex; align-items: center; justify-content: flex-end; border-bottom: 1px solid var(--border-color); position: sticky; top: 0; z-index: 900; box-shadow: 0 2px 12px rgba(0,0,0,0.05); }
        .profile-dropdown { position: relative; margin-left: 0; }
        .profile-trigger { display: flex; flex-direction: column; align-items: center; cursor: pointer; padding: 0; border-radius: 14px; transition: background 0.18s; background: none; }
        .profile-img-wrapper { display: flex; align-items: center; justify-content: center; background: #f7f8fd; border-radius: 50%; box-shadow: 0 2px 8px #8882; width: 38px; height: 38px; margin-bottom: 4px; }
        .profile-img { width: 30px; height: 30px; border-radius: 50%; object-fit: cover; box-shadow: 0 1px 4px #8882; border: 1.5px solid #fff; }
        .aesthetic-profile-info { display: flex; flex-direction: column; align-items: center; }
        .profile-name { font-size: 8px; font-weight: 700; color: #232946; margin-bottom: 1px; letter-spacing: 0.01em; }
        .profile-role { font-size: 8px; color: #a855f7; font-weight: 600; margin-bottom: 2px; }
        .profile-chevron { color: #888; font-size: 1.1rem; margin-top: 1px; }
        .dropdown-menu { display: none; position: absolute; top: 50px; right: 0; min-width: 170px; background: #fff; border-radius: 12px; box-shadow: 0 4px 18px rgba(33, 150, 243, 0.13); padding: 12px 0 6px 0; z-index: 1001; }
        .dropdown-menu.show { display: block; }
        .badge-pro { background: #e0f7e9; color: #22c55e; font-weight: 700; border-radius: 6px; padding: 3px 8px; font-size: 0.8rem; margin-left: 10px; margin-bottom: 6px; display: inline-block; }
        .dropdown-item { display: flex; align-items: center; gap: 8px; padding: 7px 16px; color: #232946; text-decoration: none; font-size: 0.95rem; border: none; background: none; transition: background 0.15s; cursor: pointer; }
        .dropdown-item:hover { background: #f3f4f6; color: #7c3aed; }
        .dropdown-item i { font-size: 1rem; }

        .header .badge {
            background: var(--primary-light);
            color: var(--primary-color);
            font-weight: 600;
            border-radius: 12px;
            padding: 8px 24px;
            font-size: 1.1rem;
            box-shadow: var(--shadow-sm);
        }

        .header .profile {
            display: flex;
            align-items: center;
            gap: 16px;
        }

        .header .profile-img {
            width: 48px;
            height: 48px;
            border-radius: 50%;
            object-fit: cover;
            margin-right: 16px;
            box-shadow: var(--shadow-sm);
        }

        .header .profile-info span {
            font-size: 1.1rem;
            font-weight: 600;
            color: var(--text-dark);
        }

        .header .profile-info small {
            color: var(--primary-color);
            font-size: 0.9rem;
        }

        .stat-card {
            background: #fff;
            border-radius: 20px;
            box-shadow: var(--shadow-sm);
            padding: 32px 24px;
            display: flex;
            align-items: center;
            margin-bottom: 28px;
            min-height: 120px;
            transition: transform 0.3s ease, box-shadow 0.3s ease;
        }

        .stat-card:hover {
            transform: translateY(-5px);
            box-shadow: 0 8px 30px rgba(0,0,0,0.1);
        }

        .stat-card .icon {
            font-size: 2.4rem;
            color: var(--primary-color);
            margin-right: 24px;
            background: var(--primary-light);
            padding: 16px;
            border-radius: 12px;
        }

        .stat-card .stat {
            font-size: 2.2rem;
            font-weight: 700;
            color: var(--text-dark);
        }

        .stat-card .label {
            font-size: 1.1rem;
            color: #a1a7bb;
            text-transform: uppercase;
            font-weight: 600;
            margin-top: 8px;
        }

        .card {
            border-radius: 20px !important;
            box-shadow: var(--shadow-sm);
            border: none;
            transition: transform 0.3s ease, box-shadow 0.3s ease;
        }

        .card:hover {
            transform: translateY(-5px);
            box-shadow: 0 8px 30px rgba(0,0,0,0.1);
        }

        .card-title {
            font-size: 1.2rem;
            font-weight: 600;
            color: var(--text-dark);
            margin-bottom: 24px;
        }

        .card .highlight {
            color: var(--primary-color);
            font-weight: 600;
        }

        .chart-container {
            min-height: 300px;
            background: #fff;
            border-radius: 16px;
            padding: 24px;
            box-shadow: var(--shadow-sm);
        }

        .mini-chart {
            height: 80px;
            background: #fff;
            border-radius: 12px;
            padding: 12px;
            box-shadow: var(--shadow-sm);
        }

        .profit-card {
            background: #fff;
            color: var(--text-dark);
            border-radius: 16px;
            padding: 24px;
            box-shadow: var(--shadow-sm);
        }

        .orders-card {
            background: var(--primary-color);
            color: #fff;
            border-radius: 16px;
            padding: 24px;
            box-shadow: 0 4px 25px rgba(124,58,237,0.2);
        }

        .orders-card .fa-bag-shopping {
            color: #fff;
            font-size: 2rem;
        }

        @media (max-width: 991px) {
            .main-content { margin-left: 0; }
            .sidebar { position: fixed; width: 280px; }
            .dashboard-container { padding: 20px 15px 0 15px; }
            .header { padding: 20px 15px; }
        }

        /* Chart.js Custom Styles */
        .chart-container canvas {
            max-height: 400px;
        }

        /* Table Styles */
        .table {
            background: #fff;
            border-radius: 16px;
            overflow: hidden;
            box-shadow: var(--shadow-sm);
        }

        .table thead th {
            background: var(--primary-light);
            color: var(--primary-color);
            font-weight: 600;
            border: none;
        }

        .table td, .table th {
            vertical-align: middle;
            padding: 16px;
        }

        .table tr:hover {
            background: var(--primary-light);
        }

        .badge {
            padding: 8px 16px;
            border-radius: 12px;
            font-size: 0.9rem;
            font-weight: 500;
        }

        .badge.bg-primary {
            background: var(--primary-color);
            color: #fff;
        }

        .btn {
            padding: 10px 24px;
            border-radius: 12px;
            font-weight: 500;
            transition: all 0.3s ease;
        }

        .btn-primary {
            background: var(--primary-color);
            border: none;
        }

        .btn-primary:hover {
            background: var(--primary-dark);
            transform: translateY(-2px);
        }

        .btn-sm {
            padding: 8px 16px;
        }
    </style>
</head>
<body>
<div class="sidebar">
    <div class="logo"><i class="fa-solid fa-flask-vial"></i> DashboardKit</div>
    <div class="section-title">Navigation</div>
    <a href="dashboard.php" class="nav-link active"><i class="fa-solid fa-house"></i>Dashboard</a>
    <a href="files.php" class="nav-link"><i class="fa-solid fa-file-lines"></i>Files</a>
    <a href="formation_requests.php" class="nav-link"><i class="fa-solid fa-chalkboard-user"></i>Formation Requests</a>
    <a href="messages.php" class="nav-link"><i class="fa-solid fa-envelope"></i>Messages <span class="badge bg-primary ms-2"><?php echo $messagesCount; ?></span></a>
</div>
<div class="main-content">
    <div class="header">
        <div style="display: flex; justify-content: flex-end; align-items: center; width: 100%; position: relative;">
            <div class="profile-dropdown" id="profileDropdown">
                <div class="profile-trigger" onclick="toggleProfileDropdown()">
                    <div class="profile-img-wrapper">
                        <img src="img/logo.jpeg" class="profile-img" alt="Profile">
                    </div>
                    <div class="profile-info aesthetic-profile-info">
                        <span class="profile-name"><?= htmlspecialchars($currentUser['name']) ?></span>
                    </div>
                    <i class="fa fa-chevron-down profile-chevron"></i>
                </div>
                <div class="dropdown-menu" id="profileDropdownMenu">
                    <span class="badge badge-pro">Pro</span>
                    <a href="profile.php" class="dropdown-item"><i class="fa fa-user"></i> Profile</a>
                    <a href="#" class="dropdown-item"><i class="fa fa-lock"></i> Lock Screen</a>
                    <a href="logout.php" class="dropdown-item"><i class="fa fa-sign-out-alt"></i> Logout</a>
                </div>
            </div>
        </div>
    </div>
    <div class="dashboard-container">
        

        <!-- Recent Activity -->
        <div class="row g-4 mb-4">
            <div class="col-md-4">
                <div class="stat-card">
                    <i class="fa-solid fa-users icon"></i>
                    <div>
                        <div class="stat"><?php
                            $loggedUsers = $pdo->query("SELECT COUNT(*) FROM users WHERE last_active IS NOT NULL")->fetchColumn();
                            echo $loggedUsers;
                        ?></div>
                        <div class="label">Logged-in Users</div>
                    </div>
                </div>
            </div>
            <div class="col-md-4">
                <div class="stat-card">
                    <i class="fa-solid fa-briefcase icon"></i>
                    <div>
                        <div class="stat"><?= $totalStages ?></div>
                        <div class="label">Stage Requests</div>
                    </div>
                </div>
            </div>
            <div class="col-md-4">
                <div class="stat-card">
                    <i class="fa-solid fa-chalkboard-user icon"></i>
                    <div>
                        <div class="stat"><?= $totalFormations ?></div>
                        <div class="label">Formation Requests</div>
                    </div>
                </div>
            </div>
            <div class="col-md-4">
                <div class="stat-card">
                    <i class="fa-solid fa-envelope icon"></i>
                    <div>
                        <div class="stat"><?= $totalMessages ?></div>
                        <div class="label">Contact Messages</div>
                    </div>
                </div>
            </div>
            <div class="col-md-4">
                <div class="stat-card">
                    <i class="fa-solid fa-check-circle icon"></i>
                    <div>
                        <div class="stat"><?php
                            $acceptedStages = $pdo->query("SELECT COUNT(*) FROM stage_requests WHERE status = 'accepted'")->fetchColumn();
                            echo $acceptedStages;
                        ?></div>
                        <div class="label">Accepted Stages</div>
                    </div>
                </div>
            </div>
            <div class="col-md-4">
                <div class="stat-card">
                    <i class="fa-solid fa-times-circle icon"></i>
                    <div>
                        <div class="stat"><?php
                            $refusedStages = $pdo->query("SELECT COUNT(*) FROM stage_requests WHERE status = 'refused'")->fetchColumn();
                            echo $refusedStages;
                        ?></div>
                        <div class="label">Refused Stages</div>
                    </div>
                </div>
            </div>
        </div>
        <div class="card p-4 mb-4">
            <div class="card-title mb-3">Stage Requests</div>
            <div class="table-responsive">
                <table class="table table-bordered align-middle">
                    <thead class="table-light">
                        <tr>
                            <th>Name</th>
                            <th>Email</th>
                            <th>CV</th>
                            <th>Status</th>
                            <th>Action</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php
                        $allStages = $pdo->query('SELECT * FROM stage_requests ORDER BY created_at DESC')->fetchAll();
                        foreach ($allStages as $stage) {
                            echo '<tr>';
                            echo '<td>' . htmlspecialchars($stage['name']) . '</td>';
                            echo '<td>' . htmlspecialchars($stage['email']) . '</td>';
                            if ($stage['cv_file']) {
                                echo '<td><a href="cv_uploads/' . urlencode($stage['cv_file']) . '" target="_blank">Download CV</a></td>';
                            } else {
                                echo '<td>No CV</td>';
                            }
                            echo '<td>' . htmlspecialchars(ucfirst($stage['status'])) . '</td>';
                            echo '<td>';
                            if ($stage['status'] === 'pending') {
                                echo '<form method="post" action="stage_status_update.php" style="display:inline-block;">';
                                echo '<input type="hidden" name="stage_id" value="' . $stage['id'] . '">';
                                echo '<button type="submit" name="action" value="accept" class="btn btn-success btn-sm me-1">Accept</button>';
                                echo '<button type="submit" name="action" value="refuse" class="btn btn-danger btn-sm">Refuse</button>';
                                echo '</form>';
                            } else {
                                echo '<span class="badge bg-secondary">' . htmlspecialchars(ucfirst($stage['status'])) . '</span>';
                            }
                            echo '</td>';
                            echo '</tr>';
                        }
                        ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</div>
<script src="js/bootstrap.min.js"></script>
<script src="js/common.js"></script>
<script src="js/dashboard.js"></script>
<script>
    // Pass PHP data to JavaScript
    window.messagesData = <?php echo json_encode($messagesPerDay); ?>;
    window.serviceData = <?php echo json_encode($serviceDistribution); ?>;
    window.stageData = <?php echo json_encode($stageStatus); ?>;
    window.userData = <?php echo json_encode($userActivity); ?>;

    // Mini Area Chart
    const ctxMiniArea = document.getElementById('miniAreaChart')?.getContext('2d');
    if (ctxMiniArea) {
        new Chart(ctxMiniArea, {
            type: 'line',
            data: {
                labels: ['2016', '2017', '2018'],
                datasets: [{
                    data: [13, 15, 10],
                    borderColor: '#7c3aed',
                    backgroundColor: 'rgba(124,58,237,0.15)',
                    fill: true,
                    tension: 0.4,
                    pointRadius: 0
                }]
            },
            options: {
                responsive: true,
                plugins: { legend: { display: false } },
                scales: { x: { display: false }, y: { display: false } },
                elements: { line: { borderWidth: 2 } }
            }
        });
    }

    // Mini Bar Chart
    const ctxMiniBar = document.getElementById('miniBarChart')?.getContext('2d');
    if (ctxMiniBar) {
        new Chart(ctxMiniBar, {
            type: 'bar',
            data: {
                labels: ['May', 'June', 'July'],
                datasets: [{
                    data: [130, 251, 235],
                    backgroundColor: '#7c3aed',
                    borderRadius: 6
                }]
            },
            options: {
                responsive: true,
                plugins: { legend: { display: false } },
                scales: { x: { display: false }, y: { display: false } }
            }
        });
    }

    // Messages Chart
    const ctxMessages = document.getElementById('messagesChart')?.getContext('2d');
    if (ctxMessages && window.messagesData) {
        new Chart(ctxMessages, {
            type: 'line',
            data: {
                labels: messagesData.map(item => item.date),
                datasets: [{
                    label: 'Messages',
                    data: messagesData.map(item => item.count),
                    borderColor: '#7c3aed',
                    tension: 0.4
                }]
            },
            options: {
                responsive: true,
                plugins: {
                    legend: { position: 'top' },
                    title: { display: true }
                },
                scales: { y: { beginAtZero: true } }
            }
        });
    }

    // Service Distribution Chart
    const serviceChart = document.getElementById('serviceChart');
    if (serviceChart && window.serviceData) {
        new Chart(serviceChart, {
            type: 'pie',
            data: {
                labels: serviceData.map(item => item.service),
                datasets: [{
                    data: serviceData.map(item => item.count),
                    backgroundColor: ['#7c3aed', '#a855f7', '#c4b5fd', '#e9d5ff', '#f3e8ff']
                }]
            },
            options: {
                responsive: true,
                plugins: {
                    legend: { position: 'top' },
                    title: { display: true }
                }
            }
        });
    }

    // Stage Request Status Chart
    const stageChart = document.getElementById('stageChart');
    if (stageChart && window.stageData) {
        new Chart(stageChart, {
            type: 'bar',
            data: {
                labels: stageData.map(item => item.status),
                datasets: [{
                    label: 'Requests',
                    data: stageData.map(item => item.count),
                    backgroundColor: '#7c3aed',
                    borderColor: '#7c3aed',
                    borderWidth: 1
                }]
            },
            options: {
                responsive: true,
                plugins: {
                    legend: { position: 'top' },
                    title: { display: true }
                },
                scales: { y: { beginAtZero: true } }
            }
        });
    }

    // User Activity Chart
    const userChart = document.getElementById('userChart');
    if (userChart && window.userData) {
        new Chart(userChart, {
            type: 'line',
            data: {
                labels: userData.map(item => item.date),
                datasets: [{
                    label: 'Active Users',
                    data: userData.map(item => item.count),
                    borderColor: '#7c3aed',
                    tension: 0.4
                }]
            },
            options: {
                responsive: true,
                plugins: {
                    legend: { position: 'top' },
                    title: { display: true }
                },
                scales: { y: { beginAtZero: true } }
            }
        });
    }

    // DOMContentLoaded for success message only
    window.addEventListener('DOMContentLoaded', function() {
        var msg = document.getElementById('successMsg');
        if (msg) {
            // You can add logic to show/hide or animate the message here
        }
    });
</script>
<script>
function toggleProfileDropdown() {
    var menu = document.getElementById('profileDropdownMenu');
    menu.classList.toggle('show');
}
document.addEventListener('click', function(event) {
    var dropdown = document.getElementById('profileDropdown');
    var menu = document.getElementById('profileDropdownMenu');
    if (!dropdown.contains(event.target)) {
        menu.classList.remove('show');
    }
});
</script>
</body>
</html>