<?php
// Configuration Google OAuth 2.0
// Tu dois remplacer ces valeurs par celles de ton projet Google Cloud

// Remplacer par tes vraies valeurs depuis Google Cloud Console
define('GOOGLE_CLIENT_ID', '785842485612-oibevklpa6bj6ouccg18jtbd8qk29lmu.apps.googleusercontent.com');
define('GOOGLE_CLIENT_SECRET', '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');
define('GOOGLE_REDIRECT_URI', 'http://localhost/project/google_callback.php');

// URL d'autorisation Google
define('GOOGLE_AUTH_URL', 'https://accounts.google.com/o/oauth2/v2/auth');
define('GOOGLE_TOKEN_URL', 'https://oauth2.googleapis.com/token');
define('GOOGLE_USERINFO_URL', 'https://www.googleapis.com/oauth2/v2/userinfo');

// Scopes demandés
define('GOOGLE_SCOPES', 'email profile');
?> 