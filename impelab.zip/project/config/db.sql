-- Création de la base de données
CREATE DATABASE IF NOT EXISTS agro_lab_db;
USE agro_lab_db;

-- Structure de la table des utilisateurs pour l'inscription/connexion
CREATE TABLE users (
    id INT AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(100) NOT NULL,
    email VARCHAR(150) NOT NULL UNIQUE,
    password VARCHAR(255) NULL,
    google_id VARCHAR(100) NULL UNIQUE,
    google_picture VARCHAR(255) NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    last_active DATETIME NULL
); 

-- Add status to stage_requests
ALTER TABLE stage_requests ADD COLUMN status VARCHAR(20) DEFAULT 'pending';
-- Add status to formation_requests
ALTER TABLE formation_requests ADD COLUMN status VARCHAR(20) DEFAULT 'pending';

-- Create messages table for contact form submissions
CREATE TABLE IF NOT EXISTS messages (
    id INT AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(100) NOT NULL,
    email VARCHAR(150) NOT NULL,
    phone VARCHAR(20),
    service VARCHAR(100) NOT NULL,
    message TEXT NOT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
); 