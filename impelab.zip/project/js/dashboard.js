// Dashboard specific JavaScript

domReady(function() {
    // Initialize charts
    initializeCharts();
    
    // Profile dropdown
    setupProfileDropdown();
    
    // Sidebar navigation
    setupSidebar();
});

function initializeCharts() {
    // Main Chart
    const ctx = document.getElementById('mainChart').getContext('2d');
    if (ctx) {
        const messagesData = JSON.parse(messagesData);
        const serviceData = JSON.parse(serviceData);
        
        new Chart(ctx, {
            type: 'line',
            data: {
                labels: messagesData.map(item => item.date),
                datasets: [{
                    label: 'Messages',
                    data: messagesData.map(item => item.count),
                    borderColor: '#4361ee',
                    tension: 0.4
                }]
            },
            options: {
                responsive: true,
                maintainAspectRatio: false,
                scales: {
                    y: {
                        beginAtZero: true
                    }
                }
            }
        });
    }
}

function setupProfileDropdown() {
    const dropdown = document.getElementById('profileDropdown');
    if (dropdown) {
        dropdown.addEventListener('click', function(e) {
            e.stopPropagation();
            this.classList.toggle('active');
        });
    }
    
    document.addEventListener('click', function() {
        const dropdown = document.getElementById('profileDropdown');
        if (dropdown && dropdown.classList.contains('active')) {
            dropdown.classList.remove('active');
        }
    });
}

function setupSidebar() {
    const sidebar = document.querySelector('.sidebar');
    const mainContent = document.querySelector('.main-content');
    
    if (sidebar && mainContent) {
        // Add click handlers for sidebar items
        sidebar.querySelectorAll('a').forEach(link => {
            link.addEventListener('click', function() {
                sidebar.querySelectorAll('.active').forEach(el => el.classList.remove('active'));
                this.classList.add('active');
            });
        });
    }
}
