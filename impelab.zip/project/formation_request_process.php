<?php
header('Content-Type: application/json');
session_start();
require_once 'config.php';

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    echo json_encode(['success' => false, 'message' => 'Méthode non autorisée.']);
    exit;
}

if (!isset($_SESSION['user_id'])) {
    echo json_encode(['success' => false, 'message' => 'Utilisateur non connecté.']);
    exit;
}

$user_id = $_SESSION['user_id'];
$title = trim($_POST['title'] ?? '');
$description = trim($_POST['description'] ?? '');
$formation = trim($_POST['formation'] ?? '');

// Debug temporaire - à enlever après vérification
// var_dump($formation);
// exit;

if (empty($title) || empty($description) || empty($formation)) {
    echo json_encode(['success' => false, 'message' => 'Tous les champs sont obligatoires.']);
    exit;
}

try {
    // Requête insensible à la casse pour éviter problème de majuscules/minuscules
    $stmt = $pdo->prepare('SELECT id FROM formation_categories WHERE LOWER(name) = LOWER(?)');
    $stmt->execute([$formation]);
    $cat = $stmt->fetch(PDO::FETCH_ASSOC);

    if (!$cat) {
        echo json_encode(['success' => false, 'message' => 'Formation introuvable.']);
        exit;
    }

    $category_id = $cat['id'];
    $stmt = $pdo->prepare('INSERT INTO formation_requests (user_id, category_id, title, description) VALUES (?, ?, ?, ?)');
    $stmt->execute([$user_id, $category_id, $title, $description]);

    echo json_encode(['success' => true, 'message' => 'Demande envoyée avec succès !']);
} catch (PDOException $e) {
    echo json_encode(['success' => false, 'message' => 'Erreur serveur : ' . $e->getMessage()]);
}
