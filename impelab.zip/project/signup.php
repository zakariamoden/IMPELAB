<?php
session_start();
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <title>Inscription - Laboratoire d'analyses agro-alimentaire</title>
    <meta content="width=device-width, initial-scale=1.0" name="viewport">
    <meta content="" name="keywords">
    <meta content="" name="description">
    <!-- Favicon -->
    <link href="img/favicon.ico" rel="icon">
    <!-- Google Web Fonts -->
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Roboto:wght@400;500&family=Red+Rose:wght@600;700&display=swap" rel="stylesheet">
    <!-- Icon Font Stylesheet -->
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.10.0/css/all.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.10.4/font/bootstrap-icons.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/line-awesome/1.3.0/line-awesome/css/line-awesome.min.css">
    <!-- Libraries Stylesheet -->
    <link href="lib/animate/animate.min.css" rel="stylesheet">
    <link href="lib/owlcarousel/assets/owl.carousel.min.css" rel="stylesheet">
    <!-- Customized Bootstrap Stylesheet -->
    <link href="css/bootstrap.min.css" rel="stylesheet">
    <!-- Template Stylesheet -->
    <link href="css/style.css" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/animate.css/4.1.1/animate.min.css" rel="stylesheet">
    <style>
    body {
      background: linear-gradient(120deg, #e0eafc 0%, #cfdef3 100%);
      min-height: 100vh;
      margin: 0;
      padding: 0;
    }
    .signup-page-wrapper {
      min-height: 70vh;
      display: flex;
      align-items: center;
      justify-content: center;
      background: none;
      margin: 40px 0 40px 0;
      z-index: 1;
      position: relative;
    }
    .form-container {
      width: 370px;
      min-height: 600px;
      height: auto;
      background: rgba(255,255,255,0.25);
      box-shadow: 0 8px 32px 0 rgba(31, 38, 135, 0.18);
      border-radius: 18px;
      box-sizing: border-box;
      padding: 32px 36px;
      display: flex;
      flex-direction: column;
      justify-content: center;
      backdrop-filter: blur(12px);
      border: 1.5px solid rgba(255,255,255,0.25);
      position: relative;
      overflow: hidden;
      transition: box-shadow 0.25s, border 0.25s;
    }
    .form-container::before {
      content: '';
      position: absolute;
      inset: 0;
      border-radius: 18px;
      background: linear-gradient(120deg, rgba(0,176,255,0.08) 0%, rgba(150, 201, 255, 0.13) 100%);
      z-index: 0;
      pointer-events: none;
    }
    .title {
      text-align: center;
      font-family: 'Red Rose', 'Lucida Sans', 'Lucida Sans Regular', 'Lucida Grande', 'Lucida Sans Unicode', Geneva, Verdana, sans-serif;
      margin: 10px 0 30px 0;
      font-size: 2rem;
      font-weight: 800;
      color: #1a3353;
      letter-spacing: 0.01em;
      z-index: 1;
    }
    .form {
      width: 100%;
      display: flex;
      flex-direction: column;
      gap: 18px;
      margin-bottom: 15px;
      z-index: 1;
    }
    .input {
      border-radius: 20px;
      border: 1.5px solid #c0c0c0;
      outline: 0 !important;
      box-sizing: border-box;
      padding: 12px 15px;
      font-size: 1.08rem;
      background: rgba(255,255,255,0.7);
      box-shadow: 0 2px 8px rgba(0,176,255,0.07);
      transition: border 0.22s, box-shadow 0.22s;
      color: #1a3353;
    }
    .input:focus {
      border: 1.5px solid #0070e0;
      box-shadow: 0 0 0 3px rgba(0,176,255,0.13), 0 2px 12px rgba(0,176,255,0.10);
      background: rgba(255,255,255,0.95);
    }
    .form-btn {
      padding: 12px 15px;
      font-family: 'Red Rose', 'Lucida Sans', 'Lucida Sans Regular', 'Lucida Grande', 'Lucida Sans Unicode', Geneva, Verdana, sans-serif;
      border-radius: 20px;
      border: 0 !important;
      outline: 0 !important;
      background: linear-gradient(90deg, #0070e0 60%, #00c6fb 100%);
      color: white;
      cursor: pointer;
      font-weight: 700;
      font-size: 1.08rem;
      box-shadow: 0 2px 12px rgba(0,112,224,0.13);
      transition: background 0.18s, box-shadow 0.18s, transform 0.18s;
      z-index: 1;
    }
    .form-btn:hover {
      background: linear-gradient(90deg, #005bb5 60%, #0099e6 100%);
      box-shadow: 0 4px 18px rgba(0,112,224,0.18);
      transform: translateY(-2px) scale(1.04);
    }
    .form-btn:active {
      box-shadow: none;
    }
    .login-label {
      margin: 0;
      font-size: 12px;
      color: #747474;
      font-family: 'Red Rose', 'Lucida Sans', 'Lucida Sans Regular', 'Lucida Grande', 'Lucida Sans Unicode', Geneva, Verdana, sans-serif;
      z-index: 1;
      text-align: center;
    }
    .login-link {
      margin-left: 3px;
      font-size: 13px;
      text-decoration: underline;
      text-decoration-color: #00c6fb;
      color: #0070e0;
      cursor: pointer;
      font-weight: 800;
      font-family: 'Red Rose', 'Lucida Sans', 'Lucida Sans Regular', 'Lucida Grande', 'Lucida Sans Unicode', Geneva, Verdana, sans-serif;
      transition: color 0.18s;
    }
    .login-link:hover {
      color: #005bb5;
    }
    @media (max-width: 500px) {
      .form-container {
        width: 98vw;
        min-width: unset;
        padding: 10px 2vw;
        height: auto;
      }
      .signup-page-wrapper {
        margin: 10px 0 10px 0;
      }
    }
    </style>
</head>
<body>
    <?php
    // Afficher les messages d'erreur
    if (isset($_SESSION['errors'])) {
        echo '<div style="position: fixed; top: 20px; right: 20px; background: #ff6b6b; color: white; padding: 15px; border-radius: 8px; z-index: 1000; max-width: 300px;">';
        foreach ($_SESSION['errors'] as $error) {
            echo '<p style="margin: 0 0 5px 0;">' . htmlspecialchars($error) . '</p>';
        }
        echo '</div>';
        unset($_SESSION['errors']);
    }
    ?>
    <!-- Topbar Start -->
    <div class="topbar py-2 animate__animated animate__fadeInDown" style="position:relative; background:linear-gradient(90deg,#2196f3 0%,#6ec6ff 100%); border-bottom:1px solid #e3eaf1; font-size:1.08rem; color:#fff; box-shadow:0 4px 18px rgba(33,150,243,0.10); border-radius:0 0 1.2rem 1.2rem; overflow:hidden; backdrop-filter:blur(4px);">
        <div class="container d-flex justify-content-center align-items-center position-relative" style="z-index:1;">
            <div class="d-flex align-items-center fw-semibold" style="letter-spacing:0.03em;">
                <span class="me-4">
                    <a href="tel:1231234567" style="color:#fff; text-decoration:none; display:inline-flex; align-items:center; font-weight:600; transition:0.18s;">
                        <i class="fas fa-phone-alt me-1"></i>
                        (123) 123-4567
                    </a>
                </span>
                <span class="me-4">
                    <a href="https://maps.app.goo.gl/PEGRF9ogjZgEwkxj8" target="_blank" style="color:#fff; text-decoration:none; display:inline-flex; align-items:center; font-weight:600; transition:0.18s;" aria-label="View on Google Maps">
                        <i class="fas fa-map-marker-alt me-1"></i>
                        <span id="user-location" style="display:inline-block; min-width:90px;">ALHAY SINAi</span>
                    </a>
                </span>
                <span class="me-4" style="display:inline-flex; align-items:center;">
                    <i class="fas fa-clock me-1"></i> Mon - Sat: 8:30am - 5:00pm
                </span>
            </div>
        </div>
    </div>
    <!-- Topbar End -->
    <!-- Main Header Start -->
    <header class="main-header py-2" style="background:#fff; box-shadow:0 2px 8px rgba(30,60,120,0.04);">
        <div class="container">
            <nav class="navbar navbar-expand-lg navbar-light p-0">
                <a class="navbar-brand d-flex align-items-center" href="#">
                    <img src="img/logo.jpeg" alt="Lab Medical Logo" style="height:80px;">
                </a>
                <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#mainNavbar" aria-controls="mainNavbar" aria-expanded="false" aria-label="Toggle navigation">
                    <span class="navbar-toggler-icon"></span>
                </button>
                <div class="collapse navbar-collapse" id="mainNavbar">
                    <ul class="navbar-nav mx-auto mb-2 mb-lg-0">
                        <li class="nav-item"><a class="nav-link" href="index.html">Home</a></li>
                        <li class="nav-item"><a class="nav-link" href="formation.html">formation</a></li>
                        <li class="nav-item"><a class="nav-link" href="stages.html">stages</a></li>
                        <li class="nav-item"><a class="nav-link" href="contact.html">Contact</a></li>
                    </ul>
                    <div class="d-flex justify-content-end">
                        <a href="login.php" class="btn btn-outline-primary rounded-pill px-4 py-2 fw-bold d-flex align-items-center" style="margin-right: 1rem;">
                            <i class="fas fa-sign-in-alt me-2"></i> Login
                        </a>
                    </div>
                </div>
            </nav>
        </div>
    </header>
    <!-- Main Header End -->
    <div class="signup-page-wrapper">
      <div class="form-container">
        <p class="title">Créer un compte</p>
        <form class="form" method="POST" action="signup_process.php">
          <input type="text" class="input" name="name" placeholder="Nom complet" required>
          <input type="email" class="input" name="email" placeholder="Email" required>
          <input type="password" class="input" name="password" placeholder="Mot de passe" required>
          <input type="password" class="input" name="confirm_password" placeholder="Confirmer le mot de passe" required>
          <button class="form-btn" type="submit">S'inscrire</button>
        </form>
        <p class="login-label">
          Vous avez déjà un compte ?<a href="login.php" class="login-link">Se connecter</a>
        </p>
        <div style="text-align: center; margin-top: 20px;">
          <p style="color: #747474; font-size: 12px; margin-bottom: 15px;">Ou s'inscrire avec</p>
          <a href="google_login.php" class="google-login-button" style="text-decoration: none; display: inline-flex; width: 100%; justify-content: center;">
            <svg stroke="currentColor" fill="currentColor" stroke-width="0" version="1.1" x="0px" y="0px" class="google-icon" viewBox="0 0 48 48" height="1em" width="1em" xmlns="http://www.w3.org/2000/svg">
              <path fill="#FFC107" d="M43.611,20.083H42V20H24v8h11.303c-1.649,4.657-6.08,8-11.303,8c-6.627,0-12-5.373-12-12
	c0-6.627,5.373-12,12-12c3.059,0,5.842,1.154,7.961,3.039l5.657-5.657C34.046,6.053,29.268,4,24,4C12.955,4,4,12.955,4,24
	c0,11.045,8.955,20,20,20c11.045,0,20-8.955,20-20C44,22.659,43.862,21.35,43.611,20.083z"></path>
              <path fill="#FF3D00" d="M6.306,14.691l6.571,4.819C14.655,15.108,18.961,12,24,12c3.059,0,5.842,1.154,7.961,3.039l5.657-5.657
	C34.046,6.053,29.268,4,24,4C16.318,4,9.656,8.337,6.306,14.691z"></path>
              <path fill="#4CAF50" d="M24,44c5.166,0,9.86-1.977,13.409-5.192l-6.19-5.238C29.211,35.091,26.715,36,24,36
	c-5.202,0-9.619-3.317-11.283-7.946l-6.522,5.025C9.505,39.556,16.227,44,24,44z"></path>
              <path fill="#1976D2" d="M43.611,20.083H42V20H24v8h11.303c-0.792,2.237-2.231,4.166-4.087,5.571
	c0.001-0.001,0.002-0.001,0.003-0.002l6.19,5.238C36.971,39.205,44,34,44,24C44,22.659,43.862,21.35,43.611,20.083z"></path>
            </svg>
            <span>S'inscrire avec Google</span>
          </a>
        </div>
      </div>
    </div>
    <!-- Footer Start -->
    <div class="container-fluid footer position-relative bg-dark text-white-50 py-5 wow fadeIn" data-wow-delay="0.1s">
        <div class="container">
            <div class="row g-5 py-5">
                <div class="col-lg-6 pe-lg-5">
                    <a href="index.html" class="navbar-brand">
                        <h1 class="h1 text-primary mb-0">Laboratoire <span class="text-white">Agro-Analyses</span></h1>
                    </a>
                    <p class="fs-5 mb-4">Laboratoire d'analyses agro-alimentaire : votre partenaire pour la sécurité, la qualité et la conformité de vos produits alimentaires.</p>
                    <p><i class="fa fa-map-marker-alt me-2"></i>123 Rue de l'Agro, Ville, Pays</p>
                    <p><i class="fa fa-phone-alt me-2"></i>+212 600 000 000</p>
                    <p><i class="fa fa-envelope me-2"></i>contact@agro-analyses.com</p>
                    <div class="d-flex mt-4">
                        <a class="btn btn-lg-square btn-primary me-2" href="#"><i class="fab fa-twitter"></i></a>
                        <a class="btn btn-lg-square btn-primary me-2" href="#"><i class="fab fa-facebook-f"></i></a>
                        <a class="btn btn-lg-square btn-primary me-2" href="#"><i class="fab fa-linkedin-in"></i></a>
                        <a class="btn btn-lg-square btn-primary me-2" href="#"><i class="fab fa-instagram"></i></a>
                    </div>
                </div>
                <div class="col-lg-6 ps-lg-5">
                    <div class="row g-5">
                        <div class="col-sm-6">
                            <h4 class="text-light mb-4">Liens utiles</h4>
                            <a class="btn btn-link" href="">À propos</a>
                            <a class="btn btn-link" href="">Contact</a>
                            <a class="btn btn-link" href="">Nos services</a>
                            <a class="btn btn-link" href="">Mentions légales</a>
                            <a class="btn btn-link" href="">Support</a>
                        </div>
                        <div class="col-sm-6">
                            <h4 class="text-light mb-4">Newsletter</h4>
                            <div class="w-100">
                                <div class="input-group">
                                    <input type="text" class="form-control border-0 py-3 px-4" style="background: rgba(255, 255, 255, .1);" placeholder="Votre adresse email"><button class="btn btn-primary px-4">S'inscrire</button>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!-- Footer End -->
    <!-- Copyright Start -->
    <div class="container-fluid copyright bg-dark text-white-50 py-4">
        <div class="container">
            <div class="row">
                <div class="col-md-6 text-center text-md-start">
                    <p class="mb-0">&copy; <a href="#">Laboratoire Agro-Analyses</a>. Tous droits réservés.</p>
                </div>
                <div class="col-md-6 text-center text-md-end">
                    <p class="mb-0">Conçu par votre équipe web</p>
                </div>
            </div>
        </div>
    </div>
    <!-- Copyright End -->
    <!-- Bootstrap Bundle JS (for navbar functionality) -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html> 