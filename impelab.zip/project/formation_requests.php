<?php
session_start();
require_once 'config.php';

if (!isset($_SESSION['user_id'])) {
    echo "Vous devez être connecté pour voir vos demandes de formation.";
    exit;
}

$user_id = $_SESSION['user_id'];

try {
    $stmt = $pdo->prepare("
        SELECT 
            fr.id,
            fc.name AS formation_name,
            fr.title,
            fr.description,
            fr.created_at
        FROM formation_requests fr
        JOIN formation_categories fc ON fr.category_id = fc.id
        WHERE fr.user_id = ?
        ORDER BY fr.created_at DESC
    ");
    $stmt->execute([$user_id]);
    $requests = $stmt->fetchAll();
} catch (PDOException $e) {
    die("Erreur : " . $e->getMessage());
}
?>

<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <title>Mes Demandes de Formation</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <style>
        .sidebar { position: fixed; top: 0; left: 0; bottom: 0; width: 250px; background: #232946; color: #fff; z-index: 1000; padding-top: 32px; display: flex; flex-direction: column; }
        .sidebar .logo { font-size: 1.5rem; font-weight: 700; letter-spacing: 1px; margin-bottom: 2rem; display: flex; align-items: center; padding-left: 32px; }
        .sidebar .logo i { font-size: 2rem; margin-right: 10px; color: #7c3aed; }
        .sidebar .section-title { font-size: 0.75rem; color: #a1a7bb; text-transform: uppercase; margin: 1.5rem 0 0.5rem 32px; letter-spacing: 1px; }
        .sidebar .nav-link { color: #e0e7ff; padding: 10px 32px; border-radius: 8px; display: flex; align-items: center; font-weight: 500; margin-bottom: 4px; transition: background 0.2s, color 0.2s; text-decoration: none; }
        .sidebar .nav-link.active, .sidebar .nav-link:hover { background: #353a5a; color: #7c3aed; }
        .sidebar .nav-link i { margin-right: 12px; font-size: 1.2rem; }
        .sidebar .disabled { opacity: 0.5; pointer-events: none; }
        .main-content { margin-left: 250px; min-height: 100vh; background: #f4f7fa; padding: 40px 40px 0 40px; }
        @media (max-width: 991px) {
            .main-content { margin-left: 0; padding: 20px 5px 0 5px; }
            .sidebar { position: relative; width: 100%; min-height: 0; }
        }
    </style>
</head>
<body>
<div class="sidebar">
    <div class="logo"><i class="fa-solid fa-flask-vial"></i> DashboardKit</div>
    <div class="section-title">Navigation</div>
    <a href="dashboard.php" class="nav-link"><i class="fa-solid fa-house"></i>Dashboard</a>
    <a href="files.php" class="nav-link"><i class="fa-solid fa-file-lines"></i>Files</a>
    <a href="formation_requests.php" class="nav-link active"><i class="fa-solid fa-chalkboard-user"></i>Formation Requests</a>
    <a href="messages.php" class="nav-link"><i class="fa-solid fa-envelope"></i>Messages</a>
</div>
<div class="main-content">
<div class="container mt-5">
    <h2 class="mb-4">Mes demandes de formation</h2>
    
    <?php if (empty($requests)) : ?>
        <div class="alert alert-info">Vous n’avez encore fait aucune demande.</div>
    <?php else : ?>
        <table class="table table-bordered table-hover">
            <thead class="table-light">
                <tr>
                    <th>#</th>
                    <th>Formation</th>
                    <th>Titre</th>
                    <th>Description</th>
                    <th>Date de demande</th>
                </tr>
            </thead>
            <tbody>
                <?php foreach ($requests as $i => $row): ?>
                    <tr>
                        <td><?= $i + 1 ?></td>
                        <td><?= htmlspecialchars($row['formation_name']) ?></td>
                        <td><?= htmlspecialchars($row['title']) ?></td>
                        <td><?= htmlspecialchars($row['description']) ?></td>
                        <td><?= htmlspecialchars($row['created_at']) ?></td>
                    </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
    <?php endif; ?>
</div>
</div>
</body>
</html>
