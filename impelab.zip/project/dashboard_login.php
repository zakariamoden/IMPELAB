<?php
session_start();

// If already logged in, redirect to dashboard
if (isset($_SESSION['user_id'])) {
    header('Location: dashboard.php');
    exit();
}

$error = '';
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $email = $_POST['email'] ?? '';
    $password = $_POST['password'] ?? '';
    if ($email === 'zakariabenelmoden@gmail.com' && $password === 'zakaria ben elmoden') {
        $_SESSION['user_id'] = 1;
        header('Location: dashboard.php');
        exit();
    } else {
        $error = 'Invalid email or password.';
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Dashboard Login</title>
    <link rel="stylesheet" href="css/bootstrap.min.css">
    <style>
        body { background: #f4f8fb; }
        .login-card { max-width: 400px; margin: 80px auto; border-radius: 1.2rem; box-shadow: 0 4px 18px rgba(33,150,243,0.07); background: #fff; padding: 2rem; }
    </style>
</head>
<body>
    <div class="login-card">
        <h2 class="mb-4 text-center">Dashboard Login</h2>
        <?php if ($error): ?>
            <div class="alert alert-danger"><?= htmlspecialchars($error) ?></div>
        <?php endif; ?>
        <form method="post">
            <div class="mb-3">
                <label for="email" class="form-label">Email</label>
                <input type="email" class="form-control" id="email" name="email" required autofocus>
            </div>
            <div class="mb-3">
                <label for="password" class="form-label">Password</label>
                <input type="password" class="form-control" id="password" name="password" required>
            </div>
            <button type="submit" class="btn btn-primary w-100">Login</button>
        </form>
    </div>
</body>
</html>
