<?php
// Database configuration
$host = 'localhost';
$dbname = 'agro_lab_db';
$username = 'root';
$password = '';

try {
    // PDO connection with error logging
    $pdo = new PDO("mysql:host=$host;dbname=$dbname;charset=utf8mb4", $username, $password, [
        PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
        PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
        PDO::ATTR_EMULATE_PREPARES => false
    ]);
    
    // Verify connection
    if ($pdo) {
        error_log("Database connection successful");
    }
    
    // Test connection
    $pdo->query("SELECT 1");
    
} catch (PDOException $e) {
    error_log("Database connection failed: " . $e->getMessage());
    error_log("Error Code: " . $e->getCode());
    error_log("Error Info: " . json_encode($e->errorInfo));
    die("Database connection failed: " . $e->getMessage());
} catch(Exception $e) {
    die("Error: " . $e->getMessage());
}
?>