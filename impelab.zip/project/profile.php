<?php
session_start();
require_once 'config.php';

if (!isset($_SESSION['user_id'])) {
    header('Location: login.php');
    exit();
}

$stmt = $pdo->prepare('SELECT * FROM users WHERE id = ?');
$stmt->execute([$_SESSION['user_id']]);
$user = $stmt->fetch(PDO::FETCH_ASSOC);

// Handle profile update
$success = '';
$error = '';
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $newName = trim($_POST['name']);
    if ($user['google_id']) {
        // Google users can only update name
        $stmt = $pdo->prepare('UPDATE users SET name = ? WHERE id = ?');
        $stmt->execute([$newName, $user['id']]);
        $success = 'Profile updated!';
    } else {
        $newPassword = trim($_POST['password']);
        if (!empty($newPassword)) {
            $hashed = password_hash($newPassword, PASSWORD_DEFAULT);
            $stmt = $pdo->prepare('UPDATE users SET name = ?, password = ? WHERE id = ?');
            $stmt->execute([$newName, $hashed, $user['id']]);
        } else {
            $stmt = $pdo->prepare('UPDATE users SET name = ? WHERE id = ?');
            $stmt->execute([$newName, $user['id']]);
        }
        $success = 'Profile updated!';
    }
    // Refresh user data
    $stmt = $pdo->prepare('SELECT * FROM users WHERE id = ?');
    $stmt->execute([$_SESSION['user_id']]);
    $user = $stmt->fetch(PDO::FETCH_ASSOC);
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>User Profile</title>
    <link rel="stylesheet" href="css/bootstrap.min.css">
    <link rel="stylesheet" href="css/style.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css">
    <style>
        body { background: #f4f8fb; }
        .profile-card { border-radius: 1.2rem; box-shadow: 0 4px 18px rgba(33,150,243,0.07); max-width: 500px; margin: 40px auto; }
        .profile-img-lg { width: 90px; height: 90px; border-radius: 50%; object-fit: cover; border: 3px solid #2196f3; }
    </style>
</head>
<body>
<div class="container py-5">
    <div class="profile-card bg-white p-4">
        <div class="text-center mb-4">
            <?php if (isset($user['google_picture']) && $user['google_picture']): ?>
                <img src="<?php echo htmlspecialchars($user['google_picture']); ?>" class="profile-img-lg mb-2" alt="Profile">
            <?php else: ?>
                <img src="img/logo.jpeg" class="profile-img-lg mb-2" alt="Profile">
            <?php endif; ?>
            <h3 class="mb-0"><?php echo htmlspecialchars($user['name']); ?></h3>
            <div class="text-muted"><?php echo htmlspecialchars($user['email']); ?></div>
            <div class="mb-2">
                <?php echo $user['google_id'] ? '<span class="badge bg-success">Google</span>' : '<span class="badge bg-info text-dark">Email</span>'; ?>
            </div>
        </div>
        <?php if ($success): ?><div class="alert alert-success"><?php echo $success; ?></div><?php endif; ?>
        <?php if ($error): ?><div class="alert alert-danger"><?php echo $error; ?></div><?php endif; ?>
        <form method="post">
            <div class="mb-3">
                <label for="name" class="form-label">Name</label>
                <input type="text" class="form-control" id="name" name="name" value="<?php echo htmlspecialchars($user['name']); ?>" required>
            </div>
            <?php if (!$user['google_id']): ?>
            <div class="mb-3">
                <label for="password" class="form-label">New Password (leave blank to keep current)</label>
                <input type="password" class="form-control" id="password" name="password">
            </div>
            <?php endif; ?>
            <button type="submit" class="btn btn-primary w-100">Update Profile</button>
        </form>
        <div class="mt-3 text-center">
            <a href="dashboard.php" class="btn btn-link">&larr; Back to Dashboard</a>
            <a href="logout.php" class="btn btn-outline-danger ms-2">Logout</a>
        </div>
    </div>
</div>
<script src="js/main.js"></script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html> 