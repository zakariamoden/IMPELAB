<?php
session_start();
require_once 'config.php';

$name = filter_var($_POST['name'] ?? '', FILTER_SANITIZE_STRING);
$email = filter_var($_POST['mail'] ?? '', FILTER_SANITIZE_EMAIL);
$phone = filter_var($_POST['mobile'] ?? '', FILTER_SANITIZE_STRING);
$service = filter_var($_POST['service'] ?? '', FILTER_SANITIZE_STRING);
$message = filter_var($_POST['message'] ?? '', FILTER_SANITIZE_STRING);

// Validate required fields
if (empty($name) || empty($email) || empty($message)) {
    echo json_encode([
        'success' => false,
        'message' => 'All fields are required'
    ]);
    exit;
}

// Check if email is valid
if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
    echo json_encode([
        'success' => false,
        'message' => 'Invalid email format'
    ]);
    exit;
}

try {
    // Insert message
    $stmt = $pdo->prepare("INSERT INTO messages (name, email, phone, service, message, created_at) VALUES (?, ?, ?, ?, ?, NOW())");
    $stmt->execute([$name, $email, $phone, $service, $message]);
    // Update last contact time
    $_SESSION['last_contact_time'] = time();
    echo json_encode([
        'success' => true,
        'message' => 'Message sent successfully'
    ]);
} catch (PDOException $e) {
    error_log("Message save failed: " . $e->getMessage());
    echo json_encode([
        'success' => false,
        'message' => 'An error occurred while saving your message'
    ]);
    exit;
}
