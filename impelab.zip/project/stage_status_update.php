<?php
session_start();
if (!isset($_SESSION['user_id'])) {
    header('Location: login.php');
    exit();
}
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['stage_id'], $_POST['action'])) {
    $stage_id = intval($_POST['stage_id']);
    $action = $_POST['action'] === 'accept' ? 'accepted' : 'refused';
    $host = 'localhost';
    $db   = 'agro_lab_db';
    $user = 'root';
    $pass = '';
    $charset = 'utf8mb4';
    $dsn = "mysql:host=$host;dbname=$db;charset=$charset";
    $options = [
        PDO::ATTR_ERRMODE            => PDO::ERRMODE_EXCEPTION,
        PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
        PDO::ATTR_EMULATE_PREPARES   => false,
    ];
    try {
        $pdo = new PDO($dsn, $user, $pass, $options);
    } catch (PDOException $e) {
        die('Database connection failed: ' . $e->getMessage());
    }
    $stmt = $pdo->prepare('UPDATE stage_requests SET status = ? WHERE id = ?');
    $stmt->execute([$action, $stage_id]);
}
header('Location: dashboard.php');
exit(); 