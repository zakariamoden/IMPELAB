<?php
session_start();
require_once 'config.php';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Validate required fields
    if (!isset($_POST['name']) || !isset($_POST['email']) || !isset($_POST['message'])) {
        echo json_encode(['success' => false, 'error' => 'All fields are required']);
        exit();
    }

    $name = trim($_POST['name']);
    $email = trim($_POST['email']);
    $message = trim($_POST['message']);
    $cv_file = null;

    // Handle file upload
    if (isset($_FILES['cv_file']) && $_FILES['cv_file']['error'] === UPLOAD_ERR_OK) {
        $allowed = ['pdf', 'doc', 'docx'];
        $ext = strtolower(pathinfo($_FILES['cv_file']['name'], PATHINFO_EXTENSION));
        if (in_array($ext, $allowed)) {
            if (!is_dir('cv_uploads')) {
                mkdir('cv_uploads', 0777, true);
            }
            $filename = uniqid('cv_') . '.' . $ext;
            $destination = 'cv_uploads/' . $filename;
            if (move_uploaded_file($_FILES['cv_file']['tmp_name'], $destination)) {
                $cv_file = $filename;
            }
        }
    }

    try {
        // Check if the table exists
        $tableCheck = $pdo->query("SHOW TABLES LIKE 'stage_requests'");
        if ($tableCheck->rowCount() == 0) {
            error_log("Table 'stage_requests' does not exist");
            echo json_encode(['success' => false, 'error' => 'Database table does not exist']);
            exit();
        }

        // Get the SQL query and parameters for debugging
        $sql = 'INSERT INTO stage_requests (name, email, cv_file, message) VALUES (?, ?, ?, ?)';
        $params = [$name, $email, $cv_file, $message];
        
        // Log the query and parameters
        error_log("SQL Query: " . $sql);
        error_log("Parameters: " . json_encode($params));
        
        $stmt = $pdo->prepare($sql);
        $stmt->execute($params);

        if (!empty($_SERVER['HTTP_X_REQUESTED_WITH']) && strtolower($_SERVER['HTTP_X_REQUESTED_WITH']) == 'xmlhttprequest') {
            // AJAX request
            echo json_encode(['success' => true]);
            exit();
        } else {
            // Normal form submission
            header('Location: stages.html?success=1');
            exit();
        }
    } catch (PDOException $e) {
        error_log("Stage request failed: " . $e->getMessage());
        error_log("Error Code: " . $e->getCode());
        error_log("Error Info: " . json_encode($e->errorInfo));
        
        // Provide more specific error message
        if ($e->getCode() == 1046) { // No database selected
            echo json_encode(['success' => false, 'error' => 'Database not selected']);
        } elseif ($e->getCode() == 1049) { // Unknown database
            echo json_encode(['success' => false, 'error' => 'Database does not exist']);
        } else {
            echo json_encode(['success' => false, 'error' => 'Database error occurred: ' . $e->getMessage()]);
        }
        exit();
    }
} else {
    header('Location: stages.html');
    exit();
}